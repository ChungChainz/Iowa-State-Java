package hw4;

import java.util.ArrayList;

import api.IComponent;

/**
 * Implementation of IComponent that contains other components. 
 * Clients are responsible for adding the subcomponents using the addComponent() 
 * method and for creating all internal connections between components. 
 * This class is not designed to be used for stateful components.
 * @author chris
 *
 */
public class CompoundComponent extends AbstractComponent{
	private ArrayList<IComponent> compArray;
	
	public CompoundComponent(int inp, int out)
	{
		super(inp,out);
		compArray = new ArrayList<>();
	}
	public void addComponent(IComponent comp)
	{
		compArray.add(comp);
	}
	public ArrayList<IComponent> getComponents()
	{
		return compArray;
	}
	@Override
	public void propagate() 
	{
		for (IComponent c : compArray) 
		{
			if (c.inputsValid()) 
				{
	                c.propagate();
	            }
	        }
	    }
}
