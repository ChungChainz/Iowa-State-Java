package hw4;

import api.IComponent;

/**
 * Implementation of a specialized CompoundComponent in which all subcomponents are identical and have one output. 
 * For each i less than n, inputs i * m up to (i + 1) * m are connected to the i-th subcomponent 
 * and the output of that subcomponent is connected to output i.
 * @author chris
 *
 */
public class MultiComponent extends CompoundComponent implements IComponent
{
	
	public MultiComponent(IComponent[] comp)
	{
		super(comp[0].inputs().length * comp.length, comp.length);
		
		for(int i = 0; i < comp.length; i++)
		{
			for(int j =  0; j < comp[j].inputs().length; j++)
			{
				comp[i].inputs()[j].invalidate();
			}
			for(int j =  0; j < comp[j].outputs().length; j++)
			{
				comp[i].outputs()[j].invalidate();
			}
		}
		int a = 0;
		int b = 0;
	
		for(IComponent c: comp)
		{
			addComponent(c);
		
			for(int i =  0; i < c.inputs().length; i++)
			{
			inputs()[a].connectTo(c.inputs()[i]);
			a++;
			}
			for(int j =  0; j < c.outputs().length; j++)
			{
			c.outputs()[j].connectTo(outputs()[b]);
			b++;
			}
		}
	}
	@Override
	public void propagate()
	{
		for(IComponent c: getComponents())
		{
			c.propagate();
		}
	}
}

