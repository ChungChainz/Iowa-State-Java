package hw4;

import api.IStatefulComponent;

/**
 * Implementation of a register with an internal "state" consisting of a fixed number of bits. 
 * If enabled, the tick() method causes the input bits to be copied to the state (provided that the inputs are valid). 
 * Outputs are always valid and equal to the state.
 * @author chris
 * extends AbstractStatefulComponent (look into this
 */
public class Register extends AbstractStatefulComponent implements IStatefulComponent
{
	public Register(int n) {
		super(n, n);
		clear();
	}
	@Override
    public void tick() 
	{
        int[] currentArr = new int[inputs().length];

        if (isEnabled() && inputsValid()) 
        {
            for (int i = 0; i < inputs().length; i++) 
            {
                currentArr[i] = inputs()[i].getValue();
            }

            for (int j = 0; j < outputs().length; j++) 
            {
                outputs()[j].set(currentArr[j]);
            }
        }
	}
	
}