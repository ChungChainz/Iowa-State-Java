package hw4;
/**
 * Implementation of an and-gate with two inputs.
 * @author chris
 *
 */
public class AndGate extends AbstractComponent{

	public AndGate()
	{
		super(2,1);
	}
	public void propagate()
	{
		if(inputsValid())
		{
		 outputs()[0].set(inputs()[0].getValue() * inputs()[1].getValue());
		}
	}
}
