package hw4;
/**
 * Implementation of a not-gate with one input.
 * @author chris
 *
 */
public class NotGate extends AbstractComponent{
	public NotGate()
	{
        super(1, 1);
    }
	@Override
    public void propagate() {
        int i = 0;

        if (inputsValid()) {
            if (inputs()[0].getValue() == 0) {
                i = 1;
            }

            outputs()[0].set(i);
        }
    }
}
