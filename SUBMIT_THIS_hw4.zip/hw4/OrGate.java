package hw4;
/**
 * Implementation of an or-gate with two inputs.
 * @author chris
 *
 */
public class OrGate extends AbstractComponent{
	public OrGate() {
        super(2, 1);
    }
	 @Override
	    public void propagate() 
	 {
	    int i = 0;

	    if (inputsValid()) 
	    {
	    	if (inputs()[0].getValue() == inputs()[1].getValue()) 
	    	{
	            i = 0;
	    	}
	    	else if (inputs()[0].getValue() == 1 || inputs()[1].getValue() == 1) 
	    	{
	    		i = 1;
	        }	
	    	

	        outputs()[0].set(i);
	     }
	  }
}
