package hw4;

import api.IComponent;

/**
 * Implementation of a standard half adder circuit. This version extends CompoundComponent.
 * @author chris
 *
 */
public class HalfAdder extends CompoundComponent
{
	private IComponent andGate;
    private IComponent orGate;
	
    public HalfAdder(){
		super(2, 2);
		andGate = new AndGate();
        orGate = new OrGate();

        addComponent(andGate);
        addComponent(orGate);

        inputs()[0].connectTo(orGate.inputs()[0]);
        inputs()[1].connectTo(orGate.inputs()[1]);

        orGate.inputs()[0].connectTo(andGate.inputs()[0]);
        orGate.inputs()[1].connectTo(andGate.inputs()[1]);

        orGate.outputs()[0].connectTo(outputs()[0]);
        andGate.outputs()[0].connectTo(outputs()[1]);
	
	}
	
}
