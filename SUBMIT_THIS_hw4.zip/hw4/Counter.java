package hw4;
import api.IStatefulComponent;
/**
 * Implementation of a binary counter with a fixed number of bits.
 * @author chris
 * Look into the AbstractStatefulComponent
 */
public class Counter extends AbstractStatefulComponent implements IStatefulComponent
{
	private int current;
	private int num;
	public Counter(int n)
	{
		super(0, n);
		this.current = 0;
		this.num = n;
		
		clear();
	}

	@Override
	public void tick() 
	{
		 if (isEnabled() && inputsValid()) 
		 {
	            invalidateOutputs();

	            current++;

	            String binary = Integer.toBinaryString(current);

	            char c = ' ';
	            int number = 0;

	            for (int i = 0; i < Math.min(binary.length(), num); i++) 
	            {
	                c = binary.charAt(binary.length() - i - 1);
	                number = Character.getNumericValue(c);
	                outputs()[i].set(number);
	            }
		 }
		
	}

}
