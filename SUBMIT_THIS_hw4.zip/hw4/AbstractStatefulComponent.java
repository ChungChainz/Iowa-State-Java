package hw4;

import api.Pin;
import api.IComponent;
/**
 * Abstract super type for stateful components.
 * @author chris
 *
 */
public abstract class AbstractStatefulComponent implements IComponent {
    private Pin[] input;
    private Pin[] output;
    private boolean enabled;

    /**
     * @param inp 
     * @param out 
     */
    protected AbstractStatefulComponent(int inp, int out) {
        input = new Pin[inp];
        output = new Pin[out];
        enabled = false;

        for (int j = 0; j < input.length; j++) {
            input[j] = new Pin(this);
        }

        for (int j = 0; j < output.length; j++) {
            output[j] = new Pin(this);
        }
    }

    /**
     * @return array of input Pin
     */
    @Override
    public Pin[] inputs() {
        return input;
    }
    /**
     * @return array of output Pins
     */
    @Override
    public Pin[] outputs() {
        return output;
    }

    /**
     * @return if all inputs are valid then it is true, false happens otherwise
     */
    @Override
    public boolean inputsValid() {
        for (Pin e : input) {
            if (!e.isValid()) {
                return false;
            }
        }

        return true;
    }

    /**
     *  @return if all outputs are valid then it is true, false happens otherwise
     */
    @Override
    public boolean outputsValid() {
        for (Pin e : output) {
            if (!e.isValid()) {
                return false;
            }
        }

        return true;
    }

    /**
     * Makes all inputs invalid.
     */
    @Override
    public void invalidateInputs() {
        for (Pin e : input) {
            if (e.isValid()) {
                e.invalidate();
            }
        }
    }

    /**
     * Makes all outputs invalid.
     */
    @Override
    public  void invalidateOutputs() {
        for (int i = 0; i < outputs().length; i++) {
            outputs()[i].set(0);
        }
    }

    /**
     * Clears the internal state, if any (sets to all zeros).
     */
    public void clear() {
        for (int i = 0; i < outputs().length; i++) {
            outputs()[i].set(0);
        }
    }

    /**
     * Propagates inputs to outputs.  Does nothing if not all inputs are valid.
     */
    @Override
    public void propagate() {

    }

    /**
     * Enables updates to the internal state, if any, when processing
     * the tick() operation.
     *
     * @param enabled
     */
    public void setEnabled(boolean state) {
        enabled = state;
    }

    /**
     * Check if it is enabled
     */
    public boolean isEnabled() {
        return  enabled;
    }
}