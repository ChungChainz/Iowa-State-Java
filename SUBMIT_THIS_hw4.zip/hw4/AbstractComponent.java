package hw4;

import api.IComponent;
import api.Pin;


/**
 * Abstract super type with common code for all components.
 * @author chris
 *
 */

public abstract class AbstractComponent implements IComponent{
 
	private Pin[] input;
	private Pin[] output;
	 /**
     * 
     * @param inp 
     * @param out 
     */
	
	protected AbstractComponent(int inp, int out)
	{
		input = new Pin[inp];
		output = new Pin[out];
		
		for(int i = 0; i < input.length; i++)
		{
			input[i] = new Pin(this);
		}
		for(int j = 0; j < output.length; j++)
		{
			output[j] = new Pin(this);
		}
	}
	
	 /**
     * @return array of input Pins
     */
	
	@Override
	public Pin[] inputs() {
		return input;
	}
	
	/**
     * @return array of output Pins
     */
	
	@Override
	public Pin[] outputs() {
		return output;
	}
	
	/**
     * @return if all inputs are valid then it is true, false happens otherwise
     */
	
	@Override
	public boolean inputsValid() {
		for(Pin p: input)
		{
			if(p.isValid())
			{
				return true;
			}
		}
		return false;
	}
	/**
     * @return if all outputs are valid then it is true, false happens otherwise
     */
	@Override
	public boolean outputsValid() {
		for(Pin p: output)
		{
			if(p.isValid())
			{
				return true;
			}
		}
		return false;
	}
	 /**
     * Makes all inputs invalid.
     */
	@Override
	public void invalidateInputs() {
		for(Pin p : input)
		{
			if(p.isValid())
			{
				p.invalidate();
			}
		}
		
	}
	/**
     * Makes all outputs invalid.
     */
	@Override
	public void invalidateOutputs() {
		for(Pin p : output)
		{
			if(p.isValid())
			{
				p.invalidate();
			}
		}
		
	}

}
	


