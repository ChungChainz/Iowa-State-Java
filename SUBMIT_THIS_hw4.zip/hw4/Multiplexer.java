package hw4;
/**
 * Implementation of a single-output multiplexer.
 * @author chris
 *
 */
public class Multiplexer extends AbstractComponent{
	private int f;
	
	public Multiplexer(int n)
	{
		super(((int) Math.pow(2, n) + n),1);
		
		this.f = n;
	}

	@Override
	public void propagate()
	{
		int constant = f - 1;
		int output = 0;
		
		for (int i = (int) (Math.pow(2, f) + f) - 1; i >= (int) (Math.pow(2, f) + f) - f; i--) 
		{
            output += inputs()[i].getValue() * Math.pow(2, constant);
            constant--;
        }

        outputs()[0].set(inputs()[output].getValue());
	}
}
