package hw2;

public class CardDispenser {

	/**
	 * Constructs a CardDispenser that uses the given clock.
	 * @param givenClock
	 */
	private TimeClock clock;
	private ParkingCard card;
	private int clockTime;
	
	public CardDispenser(TimeClock givenClock)
	{
		clock = givenClock;
	}
	/**
	 * Constructs and returns a new ParkingCard object.  
	 * The constructed card will have a start time based on the current value 
	 * of the card dispenser's clock and a payment time of zero.
	 * @return
	 */
	public ParkingCard takeCard()
	{
		clockTime = clock.getTime();
		card = new ParkingCard(clockTime); 
		card.setPaymentTime(0);
		
		return card;
	} 
}
