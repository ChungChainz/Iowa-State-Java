package hw2;

public class ExitGate {
	
	private TimeClock initialClock;
	
	private int exitCounter;

	/**
	 * Constructs an ExitGate that uses the given clock and has an initial count of zero.
	 * @param givenClock
	 */
	
	public ExitGate(TimeClock givenClock)
	{
		initialClock = givenClock;
	}
	/**
	 * Simulates inserting a card into this machine.  
	 * If the card's payment time is within RateUtil.EXIT_TIME_LIMIT minutes of this machine's clock time 
	 * (and is greater than zero), the method returns true.  
	 * Otherwise the method returns false.  The ParkingCard object is not modified.
	 * If the method returns true, this machine's exit count is incremented.  
	 * (Note that this method is a mutator method that also returns a value.)
	 * @param c
	 * @return
	 */
	public boolean insertCard(ParkingCard c)
	{
		if(c.getPaymentTime() == 0)
		{
			return false;
		}
		
		else if(Math.max(initialClock.getTime() - c.getPaymentTime(), 0) <= RateUtil.EXIT_TIME_LIMIT)
		{
			exitCounter += 1;
			return true;
		}
		else
		{
			return false;
		}
		
	}
	/**
	 * Returns a count of the total number of successful exits. 
	 * A "successful exit" is defined to be a call to insertCard() that returns true.  
	 * @return
	 */
	public int getExitCount()
	{
		return exitCounter;
		
	}
}
