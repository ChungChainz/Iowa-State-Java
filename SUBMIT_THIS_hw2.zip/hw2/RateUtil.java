package hw2;
/**
 * This is a "utility" class, that is, it has no instance variables, is never instantiated, 
 * and serves only as a container for one or more static methods.  
 * (Similar to the class Math.) Note: in implementing the parking rates (see the section "Current parking rates", below) 
 * there are many literal numeric values to deal with.  
 * It is ok to hard-code these literal values. Your ExitGate should use the constant EXIT_TIME_LIMIT.
 * @author chris
 *
 */
public class RateUtil {
	
	

	private RateUtil()
	{
	}
	public static final int EXIT_TIME_LIMIT = 15;
	/**
	 * Returns the cost of parking for the given total number of minutes, based on the current rates for the MU garage.  
	 * See the section "Current parking rates", below, for details.
	 * @param minutes
	 * @return
	 */
	public static double calculateCost(int minutes)
	{
		int hours = minutes / 60;
		int hoursRemaining = hours % 24;
		int minsRemaining = minutes % 60;
		int days = hours / 24;
		int maxFee = 13;	
		double cost;
		
			if(minutes < 31)
			{
				return 1.0;
			}
			else if(minutes < 61) 
			{
				return 2.0;
			}
			else if(minutes < 301)
			{
				if(minsRemaining > 0)
				{
					cost = 2.00 + (hours) * 1.50;
					return cost;
				}
				else
				{
					cost = 2.00 + (hours - 1) * 1.50;
					return cost;
				}
			
			}
			else if(minutes < 481)
			{
				if(minsRemaining > 0)
				{
					cost = 8.00 + (hours - 4) * 1.25;
					return cost;
				}
				else
				{
					cost = 8.00 + (hours - 5) * 1.25;
					return cost;
				}
			}
			else if(minutes < 1441)
			{
				return maxFee;
			}
			else
			{
				if(hoursRemaining < 1)
				{
					if(minsRemaining < 31)
					{
						cost = (maxFee * days) + 1.0;
						return cost;
					}
					else
					{
						cost = (maxFee * days) + 2.0;
						return cost;
					}
				}
				else if(hoursRemaining >= 1 && hoursRemaining < 5)
					
					if(minsRemaining > 0)
					{
						cost = (2.00 + (hoursRemaining) * 1.50) + (maxFee * days);
						return cost;
					}
					else
					{
						cost = (2.00 + (hoursRemaining - 1) * 1.50) + (maxFee * days);
						return cost;
					}
				else if(hoursRemaining == 5)
				{
					if(minsRemaining > 0)
					{
						cost = (8.00 + (hoursRemaining - 4) * 1.25) + (maxFee * days);
						return cost;
					}
					else
					{
						cost = (2.00 + (hoursRemaining - 1) * 1.50) + (maxFee * days);
						return cost;
					}
				}
				else if(hoursRemaining > 5 && hoursRemaining <= 9)
					
					if(minsRemaining > 0)
					{
						cost = (8.00 + (hoursRemaining - 4) * 1.25) + (maxFee * days);
						return cost;
					}
					else
					{
						cost = (8.00 + (hoursRemaining - 5) * 1.25) + (maxFee * days);
						return cost;
					}
				else
				{
					cost = (maxFee * days) + maxFee;
					return cost;		
				}
			}
		}
	}


