package edu.iastate.cs228.hw4;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * This will take a file, create a tree for a decoding a message.
 * There will also be some outputs and extra stats.
 * @author Christopher Molis
 *
 */
public class MsgTree {
	
	public char payloadChar;
	public MsgTree left;
	public MsgTree right;
	
	private static String message = "";
	private static int staticCharIdx = 0;
	/**
	 * Constructor building the tree from a string
	 * @param encodingString
	 */
	public MsgTree(String encodingString)
	{
		char c = encodingString.charAt(staticCharIdx);
		
		if(c == '^')
		{
			staticCharIdx++;
			left = new MsgTree(encodingString);
			right = new MsgTree(encodingString);
		}
		else
		{
			this.payloadChar = c;
			staticCharIdx++;
		}
	}
	
	public static void main(String[] args) throws FileNotFoundException
	{
		
		Scanner scnr = new Scanner(System.in);
		int idx = 0;
		String encode;
		String coded;
		
		System.out.println("Enter filename for decoding:");
		File arch = new File(scnr.next());
		
		Scanner scnr2 = new Scanner(arch);
		Scanner scnr3 = new Scanner(arch);
		
		while(scnr2.hasNextLine())
		{
			idx++;
			scnr2.nextLine();
		}
		encode = scnr3.nextLine();
		
		if(idx == 3)
		{
			encode += '\n';
			encode += scnr3.nextLine();
		}
		
		coded = scnr3.nextLine();
		
		MsgTree tree = new MsgTree(encode);
		
		 System.out.println();
	        
		 System.out.println("character    code");
	     System.out.println("-------------------------");
	     printCodes(tree, "");

	     System.out.println();
	     System.out.println("MESSAGE:");
	     tree.decode(tree, coded);

	      
	     double space = (1 - ((double) coded.length() / (message.length() * 16))) * 100;

	     System.out.println("\n"); 
	     System.out.println("STATISTICS:");
	     System.out.println("Avg bits/char:" + "\t " + ((double) coded.length() / message.length()));
	     System.out.println("Total characters:" + "\t " + (message.length()));
	     System.out.println("Space savings:" + "\t " + (space + "%"));
	     
	     scnr.close();
	     scnr2.close();
	     scnr3.close();
	}
	/**
	 * Constructor for a single node with null children
	 * @param payloadChar
	 */
	public MsgTree(char payloadChar)
	{
		this.payloadChar = payloadChar;
	}
	/**
	 * method to print characters and their binary codes
	 * @param root
	 * @param code
	 */
	public static void printCodes(MsgTree root, String code)
	{
		if(root == null)
			return;
		
		if(root.left == null && root.right == null)
		{
			if(root.payloadChar == '\n')
				System.out.println("\\n" + "            " + code);
			else
			{
				System.out.println(root.payloadChar + "            " + code);
			}
		}
		printCodes(root.left, code + "0");
		printCodes(root.right, code + "1");
	}
	/**
	 * decodes the tree of codes and message given and
	 * outputs what the message says.
	 * @param codes
	 * @param msg
	 */
	public void decode(MsgTree codes, String msg)
	{
		if(codes == null)
		{
			return;
		}
		String stringMsg = msg;
		MsgTree temp = codes;
		message = "";
		
		while(stringMsg.length() > 0)
		{
			if(stringMsg.charAt(0) == '0')
			{
				temp = temp.left;
			}
			else
			{
				temp = temp.right;
			}
			if(temp.right == null && temp.left == null)
			{
				message += temp.payloadChar;
				System.out.print(temp.payloadChar);
				temp = codes;
			}
			stringMsg = stringMsg.substring(1);
		}
	}
	
	

}
