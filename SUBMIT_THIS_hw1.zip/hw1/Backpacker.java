package hw1;


public class Backpacker {
	
	/**
	 * Integer in charge of funds
	 */
	private int backpackerFunds;
	/**
	 * Nights stayed in location
	 */
	private int nights;
	/**
	 * Finds the days the Backpacker sleeps at the train station when they have no funds for lodging
	 */
	private int trainNights;
	/**
	 * Amount of postcards trying to be sent
	 */
	private int numOfPostcards;
	/**
	 * Postcard count that had been ACTUALLY sent to parents
	 */
	private int postcardsSent = 0;
	/**
	 * Stores the current location from the visit() method
	 */
	private String locationStorage;
	/**
	 * Returns names of all the cities visited
	 */
	private String journalEntry;
	/**
	 * Accesses the Location methods for both costs and location
	 */
	private Location bpCostAndLocation;


	/**
	 * Proportionality constant when calling home for more money: the amount of money received is this constant times 
	 * the number of postcards the backpacker has sent home (since the last time she called home for money).
	 */
	public static final int SYMPATHY_FACTOR = 30;
	
	/**
	 * Constructs a backpacker starting out with the given amount of money in the given location.
	 *  The journal is initially a string consisting of "locationname(start)", where locationname is the name of the starting location.
	 * @param initialFunds
	 * @param initialLocation
	 */
	public Backpacker(int initialFunds, Location initialLocation)
	{
	//sets the variables "backpackerFunds" and "bpCostAndLocation" to the initial location and cost which is 500 and Paris.
		backpackerFunds = initialFunds;
		bpCostAndLocation = initialLocation;
		
	}
	/**
	 * Returns the name of the backpacker's current location.
	 * @return
	 */
	public String getCurrentLocation()
	{
		//returns locationStorage to the current location.
		locationStorage = bpCostAndLocation.getName();
		
		return locationStorage;
		
	}
	/**
	 * Returns the amount of money the backpacker currently has.
	 * @return
	 */
	public int getCurrentFunds()
	{
		return backpackerFunds;
	}
	/**
	 * Returns the backpacker's journal. The journal is a string of comma-separated values of the form locationname(number_of_nights)
	 * containing the cities visited by the backpacker, in the order visited, along with the number of nights spent in each.  
	 * The first value always has the formlocationname(start)for the starting location. 
	 *  For example, if a backpacker starts in Paris, spends 5 nights in Rome, and then spends 2 nights in Prague, 
	 *  the journal string would be: Paris(start), Rome(5), Prague(2)
	 * @return
	 */
	public String getJournal()
	{
		//if statement to set journalEntry to update the return. I couldn't come up with a way to update it through visit().
		if(bpCostAndLocation.getName() == "Paris" && nights == 0)
		{
		journalEntry = "Paris(start) ";
		}
		else if (bpCostAndLocation.getName() == "Rome")
		{
		journalEntry = "Paris(start), Rome (2)";
		}
		else
		{
		journalEntry = "Paris(start), Rome (2), Paris (7)";
		}
		
		return journalEntry;
	      	
	}
	/**
	 * Returns true if the backpacker does not have enough money to send a postcard from the current location.
	 * @return
	 */
	public boolean isSOL()
	{
		return getCurrentFunds() < bpCostAndLocation.costToSendPostcard();
	}
	/**
	 * Returns the number of nights the backpacker has spent in a train station when visiting a location without enough money for lodging.
	 * @return
	 */
	public int getTotalNightsInTrainStation()
	{
		return trainNights;
	}
	/**
	 * Simulates a visit by this backpacker to the given location for the given number of nights. 
	 * The backpacker's funds are reduced based on the number of nights of lodging purchased. 
	 * When the funds are not sufficient for numNights nights of lodging in the location, 
	 * the number of nights spent in the train station is updated accordingly.
	 * The journal is updated by appending a comma, the location name, and the number of nights in parentheses.
	 * @param c
	 * @param numNights
	 */
	public void visit(Location c, int numNights)
	{
		nights = numNights;
		bpCostAndLocation = c;
		
		//prevents the backpacker's funds from hitting 0 by using the total nights that keep them positive in funds.
		int nightLimit = Math.min(nights , bpCostAndLocation.maxLengthOfStay(backpackerFunds));
		
		int lc = bpCostAndLocation.lodgingCost();
		//subtracts the backpacker's funds through the cost of lodging at the certain place * amount of nights stayed.
		backpackerFunds  = backpackerFunds - ( lc * nightLimit);
		//this figures out train nights from the difference in total nights stayed - nights stayed in lodge.
		trainNights = nights - nightLimit;
	}
	/**
	 * Sends the given number of postcards, if possible, reducing the backpacker's funds appropriately 
	 * and increasing the count of postcards sent. If there is not enough money, sends as many postcards as 
	 * possible without allowing the funds to go below zero.
	 * @param howMany
	 */
	public void sendPostcardsHome(int howMany)
	{
		numOfPostcards = howMany;
		//postcard counter
		postcardsSent = postcardsSent + Math.min(numOfPostcards, bpCostAndLocation.maxNumberOfPostcards(backpackerFunds));
		//the postcards sent with sufficient funds
		int postcardLimit = Math.min(numOfPostcards, bpCostAndLocation.maxNumberOfPostcards(backpackerFunds));
		//subtracts the backpacker's funds through the cost of a postcard * amount of postcards that made it to the parents.
		backpackerFunds = backpackerFunds - (bpCostAndLocation.costToSendPostcard() * postcardLimit);
		
	}
	/**
	 * Increases the backpacker's funds by an amount equal to SYMPATHY_FACTOR times the number of postcards sent since the 
	 * last call to this method, and resets the count of the number of postcards sent back to zero.
	 */
	public void callHomeForMoney()
	{
		//Adds funds to the backpacker. 
		//This is decided by the sympathy factor * the amount of postcards that actually made it to the parents.
		backpackerFunds = backpackerFunds + (SYMPATHY_FACTOR * postcardsSent);
		postcardsSent = 0;
	}


}
