package hw1;

public class Location {
	/**
	 * Name of Place	
	 */
	private String name;
	/**
	 * Cost per night	
	 */	
	private int cost;
	/**
	 * Amount of nights and postcards Backpacker is able to stay with given funds
	 */
	private int maxAmount;
	/**
	 * Cost to send postcard
	 */
	private double postcardCost;
	
	/**
	 * The cost to mail a postcard from a location is this fraction times the location's lodging cost 
	 * (rounded to the nearest integer).
	 */
	public static final double RELATIVE_COST_OF_POSTCARD= 0.05;
	/**
	 * Constructs a new Location with the given name and lodging cost per night.
	 * @param givenName
	 * @param givenLodgingCost
	 */
	public Location(String givenName, int givenLodgingCost)
	{
		name = givenName;
		cost = givenLodgingCost;
	}
	/**
	 * Returns this location's name.
	 * @return
	 */
	public String getName()
	{
		return name;
	}
	/**
	 * Returns this location's lodging cost per night.
	 * @return
	 */
	public int lodgingCost()
	{
		return cost;
	}
	/**
	 * Returns the cost to send a postcard from this location. 
	 * The value is a percentage of the lodging cost specified by the constant RELATIVE_COST_OF_POSTCARD, 
	 * rounded to the nearest integer.
	 * @return
	 */
	public int costToSendPostcard()
	{	
		postcardCost = cost * RELATIVE_COST_OF_POSTCARD;
		
		//Rounds the doubled answer to nearest int.
		int i = (int)Math.round(postcardCost);
		return i;
	}
	/**
	 * Returns the number of nights of lodging in this location that a backpacker could afford with the given amount of money.
	 * @param funds
	 * @return
	 */
	public int maxLengthOfStay(int funds)
	{
		maxAmount = funds / cost;
		
		return maxAmount;
	}
	/**
	 * Returns the number of postcards that a backpacker could afford to send from this location with the given amount of money.
	 * @param funds
	 * @return
	 */
	public int maxNumberOfPostcards(int funds)
	{
		postcardCost = cost * RELATIVE_COST_OF_POSTCARD;
		
		//Rounds the doubled answer to nearest int.
		int i = (int)Math.round(postcardCost);
		
		//Finds max amount of postcards they can buy with their current funds.
		maxAmount = funds / i;
		
		return maxAmount;
	}
}
