package edu.iastate.cs228.hw3;
/**
 * 
 * @author Christopher Molis
 * Class is converting a file from infix to postfix and printing it in an output file
 */
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.util.Scanner;
import java.util.Stack;

public class Infix2Postfix {
	public static void main(String[] args) throws Exception
	{
		File file = new File("input.txt");
		Scanner scnr = new Scanner(file);
		
		FileOutputStream fos = new FileOutputStream("output.txt");
		BufferedWriter fw = new BufferedWriter(new OutputStreamWriter(fos));
		
		while(scnr.hasNextLine())
		{
		String express = scnr.nextLine();
		
		fw.write(converter(express).strip());
		fw.newLine();
		}
		fw.close();
		scnr.close();
	}
	/**
	 * changes the infix to postfix one character at a time using the string expression
	 * @param express
	 * @return
	 */
	private static String converter(String express)
	{
		String postfix = new String("");
		
		int futureInd = 0;
		char stored = ' '; // to store previous character
		
		Stack<Character> stack = new Stack<>();
		
		for(int i = 0; i < express.length(); ++i)
		{
			if(i != express.length() - 1) //looks at express string one ahead
			{
				futureInd++;
			}
			
			char c = express.charAt(i); //main character
			char fc = express.charAt(futureInd); //one character ahead
			
			if(Character.isDigit(c))
			{
				postfix += c;
				stored = c; 
			}
			else if(Character.isWhitespace(c))
			{
				if(Character.isDigit(stored) && Character.isDigit(fc) || Character.isDigit(stored) && fc == '(')
				{
					return "Error: too many operands (" + fc + ")";
				}
				if(prec(fc) == -1 || prec(fc) == 0 || prec(fc) == 1 || prec(fc) == 2 || prec(fc) == 3)
				{
					postfix += "";
				}
				else
				postfix += " ";
			}
			else if(c == '(')
			{
				if(stored == ')')
				{
					return "Error: too many operands (" + fc + ")";
				}
				
				stored = c;
				if(Character.isWhitespace(fc))
				{
					postfix += "";
				}
				
				stack.push(c);
			}
			else if(c == ')')
			{
				while(!stack.isEmpty() && stack.peek() != '(')
				{
					postfix += " ";
					postfix += stack.pop();
				}
				if(stored == '(')
					return "Error: no subexpression detected ()";
				
				stored = c;
				if(stack.isEmpty())
				return "Error: No opening parenthesis detected";
				
				if(stack.peek() == '(')
				stack.pop();
				else
				return "Error: No opening parenthesis detected";
					
			}
			else if(c == '-')
			{
				if(Character.isDigit(fc))
				{
					postfix += " ";
					postfix += c;
				}
				else if(stored == ' ' || stored == '+' || stored == '-' || stored == '*' ||stored == '/' ||
						stored == '%' || stored == '^' || stored == '(' )
				{
					return "Error: too many operators (" + c + ")";
				}
				else
				{
					while(!stack.isEmpty() && prec(c) <= prec(stack.peek()))
					{
						 postfix += " ";
						postfix += stack.pop();
					}
					stack.push(c);
					stored = c;
				}
			}
			else
			{
				if(stored == ' ' || stored == '+' || stored == '-' || stored == '*' ||stored == '/' ||
						stored == '%' || stored == '^' || stored == '(')
				{
					return "Error: too many operators (" + c + ")";
				}
				
				stored = c;
				
				while(!stack.isEmpty() && prec(c) <= prec(stack.peek()))
				{
					postfix += " ";
					postfix += stack.pop();
					
				}
				stack.push(c);
			}
		}
		  	while (!stack.isEmpty())
		  	{
	            if(stack.peek() == '(')
	                return "Error: No closing parenthesis detected";
	           
	            postfix += " ";
	            postfix += stack.pop();
	        }
		  	if(stored == '+' || stored == '-' || stored == '*' ||stored == '/' || stored == '%')
		  	{
		  		return "Error: too many operators (" + stored + ")";
		  	}
		return postfix;
	}
	/**
	 * sets precedence for symbols
	 * @param ch
	 * @return
	 */
	private static int prec(char ch)
	{
		switch(ch)
		{
		
		case '+':
		case '-':
			return 1;
		
		case '*':
		case '/':
		case '%':
			return 2;
		
		case '^':
			return 3;
			
		case '(':
			return -1;
			
		case ')':
			return 0;
		}
		
		return 5;
	}

}

