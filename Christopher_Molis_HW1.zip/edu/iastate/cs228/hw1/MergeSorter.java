package edu.iastate.cs228.hw1;



/**
 *  
 * @author Christopher Molis
 *
 */

/**
 * 
 * This class implements the mergesort algorithm.   
 *
 */

public class MergeSorter extends AbstractSorter
{
	/** 
	 * Constructor takes an array of points.  It invokes the superclass constructor, and also 
	 * set the instance variables algorithm in the superclass.
	 *  
	 * @param pts   input array of integers
	 */
	public MergeSorter(Point[] pts) 
	{
		super(pts);
		algorithm = "mergesort";
	}


	/**
	 * Perform mergesort on the array points[] of the parent class AbstractSorter. 
	 * 
	 */
	@Override 
	public void sort()
	{
		mergeSortRec(points);
	}

	
	/**
	 * This is a recursive method that carries out mergesort on an array pts[] of points. One 
	 * way is to make copies of the two halves of pts[], recursively call mergeSort on them, 
	 * and merge the two sorted subarrays into pts[].   
	 * 
	 * @param pts	point array 
	 */
	private void mergeSortRec(Point[] pts)
	{
		if(pts.length <= 1)
		{
			return;
		}
		
		int middle = pts.length / 2;
		
		Point[] left = new Point[middle];
		
		Point[] right = new Point[pts.length - middle];
		
		int i = 0;
		
		for(int j = 0; j < left.length; j++)
		{
			left[j] = pts[i++];
		}
		for(int k = 0; k < right.length; k++)
		{
			right[k] = pts[i++];
		}
		mergeSortRec(left);
		mergeSortRec(right);
		merge(pts, left, right);		
	}
	/**
	 * Merges both sub arrays. Part of the recursive mergeSortRec method.
	 * @param lastArr
	 * @param left
	 * @param right
	 */
	
	private void merge(Point[] lastArr, Point[] left, Point[] right)
	{
		int i = 0, j = 0, k = 0;
		
		while(j < left.length && k < right.length)
		{
			if(pointComparator.compare(left[j], right[k]) < 0)
			{
				lastArr[i++] = left[j++];
			}
			else
			{
				lastArr[i++] = right[k++];
			}
		}
		while(j < left.length)
		{
			lastArr[i++] = left[j++];
		}
		while(k < right.length)
		{
			lastArr[i++] = right[k++];
		}
	}
}
