package edu.iastate.cs228.hw1;

/**
 *  
 * @author Christopher Molis
 *
 */

/**
 * 
 * This class executes four sorting algorithms: selection sort, insertion sort, mergesort, and
 * quicksort, over randomly generated integers as well integers from a file input. It compares the 
 * execution times of these algorithms on the same input. 
 *
 */

import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Random; 


public class CompareSorters 
{
	/**
	 * Repeatedly take integer sequences either randomly generated or read from files. 
	 * Use them as coordinates to construct points.  Scan these points with respect to their 
	 * median coordinate point four times, each time using a different sorting algorithm.  
	 * 
	 * @param args
	 **/
	public static void main(String[] args) throws FileNotFoundException
	{		
		int option = 1;
		int trial = 1;
		Scanner scnr = new Scanner(System.in);
		System.out.println("Performances of the Four Sorting Algorthms in Point Scanning\n"
				+ "keys: 1 (random integers) 2 (file input) 3 (exit)");
		while(option == 1 || option == 2 || (option == 0 && trial == 1))
		{
			PointScanner[] scanners = new PointScanner[4]; 
			System.out.println("Trial " + trial + ": ");
			option = scnr.nextInt();
			
			if(option == 1)
			{
				System.out.println("Enter the number of random points: ");
				int counter = scnr.nextInt();
				Point[] points = generateRandomPoints(counter, new Random());
				scanners[0] = new PointScanner(points, Algorithm.SelectionSort);
				scanners[1] = new PointScanner(points, Algorithm.InsertionSort);
				scanners[2] = new PointScanner(points, Algorithm.MergeSort);
				scanners[3] = new PointScanner(points, Algorithm.QuickSort);
			}
			else if(option == 2)
			{
				System.out.print("Points fomr a file\n File name: ");
				String file = scnr.next();
				scanners[0] = new PointScanner(file, Algorithm.SelectionSort);
				scanners[1] = new PointScanner(file, Algorithm.InsertionSort);
				scanners[2] = new PointScanner(file, Algorithm.MergeSort);
				scanners[3] = new PointScanner(file, Algorithm.QuickSort);
			}
			else 
				break; //this is for the first iteration.
			
			System.out.println("algorithm   " + "size   " + "time   " + "(ns)\n"
					+ "---------------------------------");
			
			for(int i = 0; i < scanners.length; i++)
			{
				scanners[i].scan();
				System.out.println(scanners[i].stats());
			}
			System.out.println("---------------------------------");
			trial++;
		}
		scnr.close();
	}
	
	/**
	 * This method generates a given number of random points.
	 * The coordinates of these points are pseudo-random numbers within the range 
	 * [-50,50] � [-50,50]. Please refer to Section 3 on how such points can be generated.
	 * 
	 * Ought to be private. Made public for testing. 
	 * 
	 * @param numPts  	number of points
	 * @param rand      Random object to allow seeding of the random number generator
	 * @throws IllegalArgumentException if numPts < 1
	 */
	public static Point[] generateRandomPoints(int numPts, Random rand) throws IllegalArgumentException
	{ 
		Point[] output = new Point[numPts];
		if(numPts < 1) 
			{
			throw new IllegalArgumentException();
			}
		for(int i = 0; i < output.length; i++)
		{
			int x = rand.nextInt(101) - 50;
			int y = rand.nextInt(101) - 50;
			output[i] = new Point (x, y);
		} 
		return output;	
		
	}
	
}
