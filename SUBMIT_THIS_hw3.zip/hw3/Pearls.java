package hw3;

import java.util.ArrayList;

import api.Cell;
import api.Direction;
import api.MoveRecord;
import api.State;
import api.StringUtil;

/**
 * Basic game state and operations for a the puzzle game "Pearls", which
 * is a simplified version of "Quell".
 * @author chris
 */
public class Pearls
{
  /**
   * Two-dimensional array of Cell objects representing the 
   * grid on which the game is played.
   */
  private Cell[][] grid;
  
  /**
   * Instance of PearlUtil to be used with this game.
   */
  private PearlUtil util;
  
  private State[] stateGrid;
  
  private int counter;
  
  private int score;
   
  private int rowSequence;
  
  private int columnSequence;
 
  private ArrayList<State> arr;
  
  private int[] posPlayer;
  
  private boolean alive;
  
  private int currentRow;
  
  private int currentColumn;
  
  private int nextRow;
  
  private int nextColumn;
  
  private boolean doPortalJump;
  /**
   * Constructs a game from the given string description.  The conventions
   * for representing cell states as characters can be found in 
   * <code>StringUtil</code>.  
   * @param init
   *   string array describing initial cell states
   * @param givenUtil
   *   PearlUtil instance to use in the <code>move</code> method
   */
  public Pearls(String[] init, PearlUtil givenUtil)
  {
    grid = StringUtil.createFromStringArray(init);
    arr = new ArrayList<State>(); 
    stateGrid = new State[arr.size()];
    util = givenUtil;
    counter = 0;
    score = 0;
    currentRow = posPlayer[0];
    currentColumn = posPlayer[1];
    alive = true;
    
    boolean found = false;
    while (!found)
    {
        for (int row = 0; row < grid.length; row++) {
            // Then, iterate through each column
            for (int column = 0; column < grid[row].length; column++) {
                // Iterate through each cell and increment pearls when found
                if (grid[row][column].isPlayerPresent()) {
                    posPlayer = new int[]{row, column};
                    found = true;
                }
            }
        }
    }
  }

/**
   * Returns the number of columns in the grid.
   * @return
   *   width of the grid
   */
  public int getColumns()
  {
    return grid[0].length;
  }
  
  /**
   * Returns the number of rows in the grid.
   * @return
   *   height of the grid
   */
  public int getRows()
  {
    return grid.length;
  }
  
  /**
   * Returns the cell at the given row and column.
   * @param row
   *   row index for the cell
   * @param col
   *   column index for the cell
   * @return
   *   cell at given row and column
   */
  public Cell getCell(int row, int col)
  {
    return grid[row][col];
  }
  
  /**
   * Returns true if the game is over, false otherwise.  The game ends when all pearls
   * are removed from the grid or when the player lands on a cell with spikes.
   * @return
   *   true if the game is over, false otherwise
   */
  public boolean isOver()
  {
	  if(!alive || won())
	  return true;
	  
	  return false;
  }
  
  /**
   * Performs a move along a state sequence in the given direction, updating the score, 
   * the move count, and all affected cells in the grid.  The method returns an 
   * array of MoveRecord objects representing the states in original state sequence before 
   * modification, with their <code>movedTo</code> and <code>disappeared</code>
   * status set to indicate the cell states' new locations after modification.  
   * @param dir
   *   direction of the move
   * @return
   *   array of MoveRecord objects describing modified cells
   */
  public MoveRecord[] move(Direction dir)
  {
	  State[] stateSequence;
      MoveRecord[] moveRecords;

      int initial = countPearls();
      stateSequence = getStateSequence(dir);
      moveRecords = new MoveRecord[stateSequence.length];
      for (int i = 0; i < stateSequence.length; i++)
      {
          moveRecords[i] = new MoveRecord(stateSequence[i], i);
      }
      util.moveBlocks(stateSequence, moveRecords);
      int playerIndex = util.movePlayer(stateSequence, moveRecords, dir);

      // Handle Collisions
      if (State.spikesAreDeadly(stateSequence[playerIndex], dir))
      {
          alive = false;
      }

      setStateSequence(stateSequence, dir, playerIndex);
      score = score + (initial - countPearls());
      counter++;
      return moveRecords;
  }
  
  public int getCurrentRow()
  {
	
	  for(int i = 0; i < grid.length - 1; i++)
	  {
		  for(int j = 0; j < grid[j].length - 1; j++)
		  {
			  if(grid[i][j].isPlayerPresent())
			  {
				  return i;
			  }
		  }
	  }
	  return 0;
  }
  
  public int getCurrentColumn()
  {
	  
	  for(int i = 0; i < grid.length - 1; i++)
	  {
		  for(int j = 0; j < grid[j].length - 1; j++)
		  {
			  if(grid[i][j].isPlayerPresent())
			  {
				  return j;
			  }
		  }
	  }
	  return 0;
  }
  
  public boolean won()
  {
	  
	  if(countPearls() == 0)
	  {
		  return true;
	  }
	  return false;
  }

  public int getMoves()
  {  
	  return counter;
  }
  
  public int getScore()
  {
	  return score;
  }
/**
 * Finds a valid state sequence in the given direction starting with the player's current position 
 *and ending with a boundary cell as defined by the method State.isBoundary. 
 *The actual cell locations are obtained by following getNextRow and getNextColumn in the given direction, 
 * and the sequence ends when a boundary state is found. 
 * A boundary state is defined by the method State.isBoundary and is different depending on whether a movable block 
 * has been encountered so far in the state sequence (the player can move through open gates and portals, but the movable blocks cannot). 
 * It can be assumed that there will eventually be a boundary state (i.e., the grid has no infinite loops). 
 * The first element of the returned array corresponds to the cell containing the player,
 * and the last element of the array is the boundary state. This method does not modify the grid or any aspect of the game state.
 */
  public State[] getStateSequence(Direction dir)
  {
	  	if(dir == Direction.UP)
	  	{
	  		arr.add(getCell(getCurrentRow(), getCurrentColumn()).getState());
	  		rowSequence = getCurrentRow() - 1;
	  		columnSequence = getCurrentColumn();
	  		while(!State.isBoundary(grid[rowSequence][columnSequence].getState(), false))
	  	{
	  		arr.add(getCell(rowSequence, columnSequence).getState());
	  		rowSequence = getNextRow(rowSequence, columnSequence, dir, false);
	  		if(grid[rowSequence][columnSequence].getState() == State.PORTAL)
	  		{
	  			rowSequence = getNextRow(rowSequence, getCurrentColumn(), dir, true);
	  			columnSequence = getNextColumn(rowSequence, getCurrentColumn(), dir, true);
	  			arr.add(getCell(rowSequence, columnSequence).getState());
	  		}
	  	}
	  		arr.add(getCell(rowSequence, columnSequence).getState());
	  		stateGrid = arr.toArray(stateGrid);
	  		return stateGrid;
	  	}
	  	
	  	if(dir == Direction.DOWN)
	  	{
	  		arr.add(getCell(getCurrentRow(), getCurrentColumn()).getState());
	  		
	  		rowSequence = getCurrentRow() + 1;
	  		columnSequence = getCurrentColumn();
	  		
	  		while(!State.isBoundary(grid[rowSequence][columnSequence].getState(), false))
	  	{
	  		arr.add(getCell(rowSequence, columnSequence).getState());
	  		columnSequence = getNextRow(rowSequence, columnSequence, dir, false);
	  		
	  		if(grid[rowSequence][columnSequence].getState() == State.PORTAL)
	  		{
	  			rowSequence = getNextRow(getCurrentRow(), columnSequence, dir, true);
	  			columnSequence = getNextColumn(getCurrentRow(), columnSequence, dir, true);
	  			arr.add(getCell(rowSequence, columnSequence).getState());
	  		}
	  	}
	  		arr.add(getCell(rowSequence, columnSequence).getState());
	  		stateGrid = arr.toArray(stateGrid);
			return stateGrid;
	  	}
		
	  	if(dir == Direction.RIGHT)
		{
	  		arr.add(getCell(getCurrentRow(), getCurrentColumn()).getState());
	  		
	  		rowSequence = getCurrentRow();
	  		columnSequence = getCurrentColumn() + 1;
	  		
	  		while(!State.isBoundary(grid[rowSequence][columnSequence].getState(), false))
	  	{
	  		arr.add(getCell(rowSequence, columnSequence).getState());
	  		columnSequence = getNextColumn(rowSequence, columnSequence, dir, false);
	  		
	  		if(grid[rowSequence][columnSequence].getState() == State.PORTAL)
	  		{
	  			rowSequence = getNextRow(getCurrentRow(), columnSequence, dir, true);
	  			columnSequence = getNextColumn(getCurrentRow(), columnSequence, dir, true);
	  			arr.add(getCell(rowSequence, columnSequence).getState());
	  		}
	  	}
	  		arr.add(getCell(rowSequence, columnSequence).getState());
	  		stateGrid = arr.toArray(stateGrid);
			return stateGrid;
		}
	  	
	  	else
		{
	  		arr.add(getCell(getCurrentRow(), getCurrentColumn()).getState());
	  		
	  		rowSequence = getCurrentRow();
	  		columnSequence = getCurrentColumn() - 1;
	  		
	  		while(!State.isBoundary(grid[rowSequence][columnSequence].getState(), false))
	  	{
	  		arr.add(getCell(rowSequence, columnSequence).getState());
	  		columnSequence = getNextColumn(rowSequence, columnSequence, dir, false);
	  		
	  		if(grid[rowSequence][columnSequence].getState() == State.PORTAL)
	  		{
	  			rowSequence = getNextRow(getCurrentRow(), columnSequence, dir, true);
	  			columnSequence = getNextColumn(getCurrentRow(), columnSequence, dir, true);
	  			arr.add(getCell(rowSequence, columnSequence).getState());
	  		}
	  	}
	  		arr.add(getCell(rowSequence, columnSequence).getState());
	  		stateGrid = arr.toArray(stateGrid);
			return stateGrid;
	  	}
	  
  }
/**
 * Sets the given state sequence and updates the player position. 
 * This method effectively retraces the steps for creating a state sequence in the given direction, 
 * starting with the player's current position, and updates the grid with the new states. 
 * The given state sequence can be assumed to be structurally consistent with the existing grid,
 *  e.g., no portal or wall cells are moved.
 * @return
 */
  public void setStateSequence(State[] states, Direction dir, int playerIndex)
  {
      grid[currentRow][currentColumn].setPlayerPresent(false);

      for (int i = 0; i < states.length; i++) {
          doPortalJump = grid[currentRow][currentColumn].getState() == State.PORTAL &&
                  states[i - 1] != State.PORTAL;

          grid[currentRow][currentColumn].setState(states[i]);

          if (i == playerIndex) {
              grid[currentRow][currentColumn].setPlayerPresent(true);
              posPlayer[0] = currentRow;
              posPlayer[1] = currentColumn;
          }
          nextRow = getNextRow(currentRow, currentColumn, dir, doPortalJump);
          nextColumn = getNextColumn(currentRow, currentColumn, dir, doPortalJump);

          currentRow = nextRow;
          currentColumn = nextColumn;
      }
  }
 /**
  * Helper method returns the next row for a state sequence in the given direction, possibly wrapping around. 
  * If the flag doPortalJump is true, then the next row will be obtained by adding the cell's row offset. 
  * (Normally the caller will set this flag to true when first landing on a portal, but to false for the second portal of the pair.)
  * @return
  */
  public int getNextRow(int row, int col, Direction dir, boolean doPortalJump)
  {
	  if(doPortalJump)
	  {
		row = row + grid[row][col].getRowOffset();
		doPortalJump = false;
		return row;
	  }
			 
	  if(dir == Direction.DOWN)
	  {
		  if(row == grid.length - 1)
		  {
			  row = 0;
		  }
		  else
		  row += 1;
	  }
	  else if(dir == Direction.UP)
		  {
		  if(row == 0)
		  {
			  row = grid.length - 1; 
		  }
		  else
		  row -= 1;
		  }
	  else
	  {
		  return row;
	  }
	  return row;
  }
 /**
  * Helper method returns the next column for a state sequence in the given direction, possibly wrapping around. 
  * If the flag doPortalJump is true, then the next column will be obtained by adding the cell's column offset. 
  * (Normally the caller will set this flag to true when first landing on a portal, but to false for the second portal of the pair.) 	
  * @return
  */
 	public int getNextColumn(int row, int col, Direction dir, boolean doPortalJump)
 	{
 		
		 if(doPortalJump)
		  {
			col = col + grid[row][col].getColumnOffset();
			doPortalJump = false;
			return col;
		  }
 		 if(dir == Direction.LEFT)
		  {
			  if(col == 0)
			  {
				  col = grid[0].length - 1;
			  }
			  else
			  col -= 1;
		  }	
		  else if(dir == Direction.RIGHT)
		  {
			  if(col == grid[0].length - 1)
			  {
				  col = 0;
			  }
			  else
		  		col += 1;
		  }
		  else
		  {
			  return col;
		  }
	  return col;
 	}
 	public int countPearls()
 	{
 		for(int i = 0; i < grid.length - 1; i++)
 		  {
 			  for(int j = 0; j < grid[j].length - 1; j++)
 			  {
 				  if(grid[i][j].getState() == State.PEARL)
 				  {
 					  counter += 1;
 				  }
 			  }
 		  }
 		  return counter;
 	}
  

  
  
}
